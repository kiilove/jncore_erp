import React from "react"
import { formatCurrency } from "../utils/numberUtils"

const InvoiceTemplate = React.forwardRef(({ sale, companyInfo }, ref) => {
  if (!sale) return null

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일`
  }

  const calculateSubtotal = () => {
    if (!sale) return 0
    return sale.items.reduce((total, item) => total + item.quantity * item.price, 0)
  }

  const calculateTax = () => {
    return Math.round(calculateSubtotal() * 0.1)
  }

  const calculateTotal = () => {
    return calculateSubtotal() + calculateTax()
  }

  return (
    <div ref={ref} className="bg-white p-8 max-w-4xl mx-auto shadow-none print:shadow-none">
      <div className="text-black">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold">거래명세서</h1>
          <p className="text-gray-600 mt-2">#{sale.id.substring(0, 8).toUpperCase()}</p>
        </div>

        <div className="grid grid-cols-2 gap-8 mb-8">
          <div>
            <h2 className="text-lg font-semibold border-b pb-2 mb-3 border-gray-400">공급자 정보</h2>
            <p className="font-medium">{companyInfo.name}</p>
            <p className="text-gray-600">{companyInfo.address}</p>
            <p className="text-gray-600">사업자번호: {companyInfo.businessNumber}</p>
            <p className="text-gray-600">연락처: {companyInfo.phone}</p>
            <p className="text-gray-600">이메일: {companyInfo.email}</p>
          </div>

          <div>
            <h2 className="text-lg font-semibold border-b pb-2 mb-3 border-gray-400">공급받는자 정보</h2>
            <p className="font-medium">{sale.customer}</p>
            <p className="text-gray-600">발행일: {formatDate(sale.date)}</p>
            <p className="text-gray-600">결제방법: {sale.paymentMethod}</p>
            <p className="text-gray-600">상태: {sale.status}</p>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-lg font-semibold border-b pb-2 mb-3 border-gray-400">품목 정보</h2>
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-400">
                <th className="py-2 text-left">품목</th>
                <th className="py-2 text-right">수량</th>
                <th className="py-2 text-right">단가</th>
                <th className="py-2 text-right">금액</th>
              </tr>
            </thead>
            <tbody>
              {sale.items.map((item, index) => (
                <tr key={index} className="border-b border-gray-300">
                  <td className="py-3">{item.name}</td>
                  <td className="py-3 text-right">{item.quantity}</td>
                  <td className="py-3 text-right">{formatCurrency(item.price)}</td>
                  <td className="py-3 text-right">{formatCurrency(item.quantity * item.price)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-end mb-8">
          <div className="w-64">
            <div className="flex justify-between py-2">
              <span className="font-medium">소계:</span>
              <span>{formatCurrency(calculateSubtotal())}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-400">
              <span className="font-medium">부가세 (10%):</span>
              <span>{formatCurrency(calculateTax())}</span>
            </div>
            <div className="flex justify-between py-2 font-bold text-lg">
              <span>총액:</span>
              <span>{formatCurrency(calculateTotal())}</span>
            </div>
          </div>
        </div>

        {sale.notes && (
          <div className="mb-8">
            <h2 className="text-lg font-semibold border-b pb-2 mb-3 border-gray-400">비고</h2>
            <p className="text-gray-600 whitespace-pre-line">{sale.notes}</p>
          </div>
        )}

        <div className="text-center text-gray-600 text-sm mt-12">
          <p>본 거래명세서는 전자적으로 발행된 문서로 법적 효력을 가집니다.</p>
          <p>
            © {new Date().getFullYear()} {companyInfo.name}. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  )
})

export default InvoiceTemplate
