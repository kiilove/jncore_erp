import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

export const generatePDF = async (element, filename) => {
  const canvas = await html2canvas(element);
  const imgData = canvas.toDataURL("image/png");
  const pdf = new jsPDF();
  const imgProps = pdf.getImageProperties(imgData);
  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
  pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
  pdf.save(filename);
};

export const formatDateForPDF = (date) => {
  return new Date(date).toLocaleDateString("ko-KR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
};

export const generateInvoicePDF = async (invoiceData, element, filename) => {
  const canvas = await html2canvas(element);
  const imgData = canvas.toDataURL("image/png");
  const pdf = new jsPDF();

  // 인보이스 헤더 추가
  pdf.setFontSize(20);
  pdf.text("인보이스", 105, 20, { align: "center" });

  // 인보이스 정보 추가
  pdf.setFontSize(12);
  pdf.text(`인보이스 번호: ${invoiceData.invoiceNumber}`, 20, 40);
  pdf.text(`발행일: ${formatDateForPDF(invoiceData.date)}`, 20, 50);
  pdf.text(`고객명: ${invoiceData.customerName}`, 20, 60);

  // 인보이스 내용 이미지 추가
  const imgProps = pdf.getImageProperties(imgData);
  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
  pdf.addImage(imgData, "PNG", 0, 70, pdfWidth, pdfHeight);

  pdf.save(filename);
};
