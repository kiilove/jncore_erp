"use client"

import { useState, useEffect } from "react"
import { addProduct, updateProduct } from "../services/productService"
import Input from "../../../components/common/Input"
import Select from "../../../components/common/Select"
import Button from "../../../components/common/Button"

const ProductForm = ({ isOpen, onClose, onSave, product, userId }) => {
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    code: "",
    description: "",
    price: 0,
    cost: 0,
    stock: 0,
    lowStockThreshold: 10,
    unit: "개",
    barcode: "",
    manufacturer: "",
    status: "active",
  })

  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState({})

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || "",
        category: product.category || "",
        code: product.code || "",
        description: product.description || "",
        price: product.price || 0,
        cost: product.cost || 0,
        stock: product.stock || 0,
        lowStockThreshold: product.lowStockThreshold || 10,
        unit: product.unit || "개",
        barcode: product.barcode || "",
        manufacturer: product.manufacturer || "",
        status: product.status || "active",
      })
    }
  }, [product])

  const categoryOptions = [
    { value: "", label: "카테고리 선택" },
    { value: "컴퓨터", label: "컴퓨터" },
    { value: "노트북", label: "노트북" },
    { value: "모니터", label: "모니터" },
    { value: "주변기기", label: "주변기기" },
    { value: "부품", label: "부품" },
  ]

  const statusOptions = [
    { value: "active", label: "판매중" },
    { value: "inactive", label: "판매중지" },
    { value: "discontinued", label: "단종" },
  ]

  const handleInputChange = (e) => {
    const { name, value, type } = e.target

    // 숫자 필드 처리
    if (type === "number") {
      setFormData({
        ...formData,
        [name]: value === "" ? 0 : Number(value),
      })
    } else {
      setFormData({
        ...formData,
        [name]: value,
      })
    }
  }

  const validateForm = () => {
    const newErrors = {}

    if (!formData.name.trim()) {
      newErrors.name = "제품명은 필수 입력 항목입니다."
    }

    if (!formData.category) {
      newErrors.category = "카테고리는 필수 선택 항목입니다."
    }

    if (formData.price < 0) {
      newErrors.price = "가격은 0 이상이어야 합니다."
    }

    if (formData.cost < 0) {
      newErrors.cost = "원가는 0 이상이어야 합니다."
    }

    if (formData.stock < 0) {
      newErrors.stock = "재고는 0 이상이어야 합니다."
    }

    if (formData.lowStockThreshold < 0) {
      newErrors.lowStockThreshold = "재고 부족 기준은 0 이상이어야 합니다."
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setLoading(true)

    try {
      if (product) {
        await updateProduct(product.id, formData, userId)
      } else {
        await addProduct(formData, userId)
      }

      onSave()
    } catch (error) {
      console.error("Error saving product:", error)
      // 에러 처리
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 dark:bg-gray-900 opacity-75"></div>
        </div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">
          &#8203;
        </span>

        <div className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full md:max-w-2xl">
          <form onSubmit={handleSubmit}>
            <div className="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
              <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white mb-4">
                {product ? "제품 정보 수정" : "새 제품 등록"}
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="제품명"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  error={errors.name}
                  required
                />

                <Select
                  label="카테고리"
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  options={categoryOptions}
                  error={errors.category}
                  required
                />

                <Input label="제품 코드" name="code" value={formData.code} onChange={handleInputChange} />

                <Input label="바코드" name="barcode" value={formData.barcode} onChange={handleInputChange} />

                <Input
                  label="판매가"
                  name="price"
                  type="number"
                  value={formData.price}
                  onChange={handleInputChange}
                  error={errors.price}
                  required
                />

                <Input
                  label="원가"
                  name="cost"
                  type="number"
                  value={formData.cost}
                  onChange={handleInputChange}
                  error={errors.cost}
                />

                <Input
                  label="재고"
                  name="stock"
                  type="number"
                  value={formData.stock}
                  onChange={handleInputChange}
                  error={errors.stock}
                />

                <Input
                  label="재고 부족 기준"
                  name="lowStockThreshold"
                  type="number"
                  value={formData.lowStockThreshold}
                  onChange={handleInputChange}
                  error={errors.lowStockThreshold}
                />

                <Input label="단위" name="unit" value={formData.unit} onChange={handleInputChange} />

                <Input label="제조사" name="manufacturer" value={formData.manufacturer} onChange={handleInputChange} />

                <Select
                  label="상태"
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                  options={statusOptions}
                />
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">제품 설명</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows="3"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                ></textarea>
              </div>
            </div>

            <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
              <Button type="submit" variant="primary" disabled={loading} className="w-full sm:w-auto sm:ml-3">
                {loading ? "저장 중..." : product ? "수정" : "등록"}
              </Button>
              <Button type="button" variant="secondary" onClick={onClose} className="w-full sm:w-auto mt-3 sm:mt-0">
                취소
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default ProductForm
