"use client"

import { Routes, Route, Navigate } from "react-router-dom"
import Layout from "./components/Layout"
import Dashboard from "./features/dashboard/pages/DashboardPage"
import Purchases from "./features/purchases/pages/PurchasesPage"
import PurchaseReportPage from "./features/purchases/pages/PurchaseReportPage"
import PaymentPage from "./features/purchases/pages/PaymentPage"
import Sales from "./features/sales/pages/SalesPage"
import Products from "./features/products/pages/ProductsPage"
import Customers from "./features/customers/pages/CustomersPage"
import SuppliersPage from "./features/suppliers/pages/SuppliersPage"
import SupplierDetailPage from "./features/suppliers/pages/SupplierDetailPage"
import SalesInvoice from "./features/sales/pages/SalesInvoicePage"
import UserManagement from "./features/users/pages/UserManagementPage"
import Login from "./features/auth/pages/LoginPage"
import { AuthProvider, useAuth } from "./contexts/AuthContext"
import { NotificationProvider } from "./contexts/NotificationContext"
import "./index.css"

// 권한이 필요한 라우트를 위한 컴포넌트
const ProtectedRoute = ({ children, requiredRole = null }) => {
  const { currentUser, hasPermission } = useAuth()

  if (!currentUser) {
    return <Navigate to="/login" replace />
  }

  if (requiredRole && !hasPermission(requiredRole)) {
    return <Navigate to="/" replace />
  }

  return children
}

function AppContent() {
  const { currentUser, loading } = useAuth()

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <NotificationProvider>
      <Routes>
        {/* 인증이 필요한 라우트 */}
        {currentUser ? (
          <Route element={<Layout />}>
            <Route path="/" element={<Dashboard />} />

            {/* 매입 관련 라우트 */}
            <Route path="/purchases" element={<Purchases />} />
            <Route path="/purchases/report" element={<PurchaseReportPage />} />
            <Route path="/purchases/payment/:id" element={<PaymentPage />} />

            {/* 공급업체 관련 라우트 */}
            <Route path="/suppliers" element={<SuppliersPage />} />
            <Route path="/suppliers/:id" element={<SupplierDetailPage />} />

            {/* 기존 라우트 */}
            <Route path="/sales" element={<Sales />} />
            <Route path="/products" element={<Products />} />
            <Route path="/customers" element={<Customers />} />
            <Route path="/sales-invoice" element={<SalesInvoice />} />
            <Route
              path="/user-management"
              element={
                <ProtectedRoute requiredRole="admin">
                  <UserManagement />
                </ProtectedRoute>
              }
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        ) : (
          // 인증이 필요하지 않은 라우트
          <>
            <Route path="/login" element={<Login />} />
            <Route path="*" element={<Navigate to="/login" replace />} />
          </>
        )}
      </Routes>
    </NotificationProvider>
  )
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  )
}

export default App
