"use client";

import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";
import { FiMenu, FiMoon, FiSun, FiUser } from "react-icons/fi";
import NotificationCenter from "../features/notifications/components/NotificationCenter";
import { useNotification } from "../contexts/NotificationContext";

const Header = ({ toggleSidebar }) => {
  const { darkMode, toggleTheme } = useContext(ThemeContext);
  const {} = useNotification();

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm z-10 transition-colors duration-200">
      <div className="flex items-center justify-between h-16 px-4 md:px-6">
        <div className="flex items-center">
          <button
            onClick={toggleSidebar}
            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none md:hidden"
          >
            <FiMenu className="h-6 w-6" />
          </button>
          <h1 className="ml-4 text-xl font-semibold text-gray-800 dark:text-white">
            JN Core ERP
          </h1>
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={toggleTheme}
            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none"
          >
            {darkMode ? (
              <FiSun className="h-5 w-5" />
            ) : (
              <FiMoon className="h-5 w-5" />
            )}
          </button>

          <NotificationCenter />

          <button className="flex items-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none">
            <FiUser className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
