// 바코드 스캐너 입력 처리를 위한 유틸리티
import { collection, query, where, getDocs } from "firebase/firestore"

// 바코드 스캐너 입력 감지 설정
export const setupBarcodeScanner = (callback, options = {}) => {
  const defaultOptions = {
    // 바코드 스캐너는 일반적으로 빠르게 문자를 입력하므로 짧은 시간 내에 입력이 완료됨
    scannerDelayMs: 20,
    // 바코드 스캐너 입력 종료 문자 (일반적으로 Enter)
    scannerEndChar: "Enter",
    // 최소 바코드 길이
    minLength: 3,
    // 바코드 입력 시간 제한 (ms)
    timeLimit: 100,
  }

  const settings = { ...defaultOptions, ...options }
  let barcode = ""
  let lastCharTime = 0
  let lastChar = ""

  // 키 입력 이벤트 핸들러
  const handleKeyDown = (e) => {
    // 현재 시간
    const currentTime = new Date().getTime()

    // 마지막 문자 입력 후 일정 시간이 지났으면 바코드 입력 시작으로 간주
    if (currentTime - lastCharTime > settings.timeLimit && lastChar !== "") {
      barcode = ""
    }

    // 바코드 종료 문자(Enter)가 입력되면 콜백 실행
    if (e.key === settings.scannerEndChar) {
      if (barcode.length >= settings.minLength) {
        callback(barcode)
      }
      barcode = ""
      e.preventDefault()
    } else if (e.key.length === 1) {
      // 일반 문자인 경우 바코드에 추가
      barcode += e.key
    }

    lastCharTime = currentTime
    lastChar = e.key
  }

  // 이벤트 리스너 등록
  document.addEventListener("keydown", handleKeyDown)

  // 정리 함수 반환
  return () => {
    document.removeEventListener("keydown", handleKeyDown)
  }
}

// 바코드 생성 (실제로는 외부 라이브러리나 API를 사용할 수 있음)
export const generateBarcode = (text) => {
  // 이 함수는 실제 바코드 이미지를 생성하지는 않지만,
  // 바코드 생성 라이브러리를 사용할 경우 여기에 구현
  return `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+P+/HgAFdgJCIiLqwAAAAABJRU5ErkJggg==`
}

// 바코드 검증
export const validateBarcode = (barcode) => {
  // 간단한 검증: 길이와 숫자/문자 조합 확인
  if (!barcode || barcode.length < 3) {
    return false
  }

  // 실제로는 더 복잡한 검증 로직이 필요할 수 있음
  // EAN, UPC, CODE128 등 바코드 형식에 따른 검증
  return true
}

// 바코드로 제품 검색
export const findProductByBarcode = async (db, barcode) => {
  try {
    const productsRef = collection(db, "products")
    const q = query(productsRef, where("barcode", "==", barcode))
    const querySnapshot = await getDocs(q)

    if (querySnapshot.empty) {
      return null
    }

    return {
      id: querySnapshot.docs[0].id,
      ...querySnapshot.docs[0].data(),
    }
  } catch (error) {
    console.error("Error finding product by barcode:", error)
    throw error
  }
}
